# StudentMate AI — Backend

FastAPI + OpenAI backend that answers questions about student life in Hungary, in **English and Hungarian**.

## Run

```bash
pip install -r requirements.txt
cp .env.example .env        # put your OPENAI_API_KEY in .env
uvicorn main:app --reload --port 8000
```

Open http://localhost:8000/docs to test it in the browser.

No API key yet? Set `MOCK_MODE=1` and the endpoint returns fake answers so the frontend can connect right away.

## Endpoints

| Method | Path        | What it does              |
|--------|-------------|---------------------------|
| GET    | `/health`   | Status, model, mock flag  |
| POST   | `/api/chat` | Ask StudentMate a question |

### `POST /api/chat`

Request:

```json
{
  "message": "How do I get a TAJ card?",
  "language": "auto",
  "history": [
    {"role": "user", "content": "Hi"},
    {"role": "assistant", "content": "Hello! How can I help?"}
  ]
}
```

- `language`: `"auto"` (answer in the student's language), `"en"` or `"hu"`.
- `history`: optional, oldest first. The last 10 messages are used.

Response:

```json
{ "reply": "...", "language": "en", "model": "gpt-4o-mini", "mock": false }
```

Errors: `422` invalid input (e.g. empty message), `502` the AI service failed.

## Frontend example

```js
const res = await fetch("http://localhost:8000/api/chat", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ message: input, language: "auto", history }),
});
if (!res.ok) throw new Error("AI error");
const data = await res.json();
history.push({ role: "user", content: input }, { role: "assistant", content: data.reply });
```

## Files

- `main.py` — API, OpenAI call, mock mode, CORS
- `prompts.py` — StudentMate system prompt and language rules
